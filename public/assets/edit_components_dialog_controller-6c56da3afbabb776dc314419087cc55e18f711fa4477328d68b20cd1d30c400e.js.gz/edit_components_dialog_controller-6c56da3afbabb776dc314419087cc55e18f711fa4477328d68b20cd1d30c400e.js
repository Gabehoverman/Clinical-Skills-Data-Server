function EditComponentsController($scope, $mdDialog, $http, system, components , editing) {

    $scope.system = system;
    $scope.components = components;
    $scope.editing = editing;

    $scope.remove = function(componentToRemove) {
        var index = indexOfItemWithID(componentToRemove, $scope.components);
        if (index > 1) {
            $scope.components.splice(index, 1);
        }
    };

    $scope.hide = function() {
        $mdDialog.hide($scope.components);
    };
}
