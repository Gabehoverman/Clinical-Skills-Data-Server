function EditComponentsController($scope, $mdDialog, $http, system, components , editing) {

    $scope.system = system;
    $scope.components = components;
    $scope.editing = editing;

    $scope.hide = function() {
        $mdDialog.hide("Done");
    };
}
