Paloma.BaseController = function(params){
  this.params = params;
};

Paloma.BaseController.prototype = {
  before: []
};

